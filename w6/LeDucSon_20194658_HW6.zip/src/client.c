#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include "connect.h"
#include "user.h"
#define BUFF_SIZE 1024
int validdateParams(int argc, char const *argv[]);

int main(int argc, char const *argv[])
{
    int client_sock;
    char buff[BUFF_SIZE + 1];
    char buff1[BUFF_SIZE + 1];
    struct sockaddr_in server_addr; /* server's address information */
    int msg_len, bytes_sent, bytes_received;
    Request request;
    Response response;
    const int SERVER_PORT = validdateParams(argc, argv); /* port to listen on */
    const char *SERVER_ADDR = argv[1];                   /* server's IP address (dotted quad) */
    // Step 1: Construct socket
    client_sock = socket(AF_INET, SOCK_STREAM, 0);

    // Step 2: Specify server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

    // Step 3: Request to connect server
    if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
    {
        printf("\nError!Can not connect to sever! Client exit imediately!\n");
        return 0;
    }

    // Step 4: Communicate with server
    int choice, isLogin = 0, isLogout = 0;
    do
    {
        printf("Menu:\n");
        printf("1. Login\n");
        printf("2. Logout\n");
        printf("Your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            if (isLogin == 1)
            {
                printf("You have already logged in!\n");
                break;
            }
            printf("Username: ");
            getc(stdin);
            scanf("%s", buff);
            getc(stdin);
            printf("Password: ");
            scanf("%s", buff1);
            getc(stdin);
            User user = newUser(buff, buff1, 0);
            initRequest(&request, login, user);
            sendRequest(client_sock, &request);
            recvResponse(client_sock, &response);
            if (response.status == success)
            {
                isLogin = 1;
                /* code */
            }

            break;
        case 2:
            if (!isLogin)
            {
                printf("You must login first!\n");
                break;
            }
            initRequest(&request, logout, NULL);
            sendRequest(client_sock, &request);
            recvResponse(client_sock, &response);
            isLogout = 1;
            break;
        }
        if (response.status == success)
        {
            printf("%s\n", response.message);
            /* code */
        }
        else
        {
            printf("Error: %s\n", response.message);
        }
        if (isLogout)
        {
            break;
        }
    } while (1);

    // Step 4: Close socket
    close(client_sock);
    return 0;
}
int validdateParams(int argc, char const *argv[])
{
    if (argc != 3)
        goto errParam;
    for (unsigned int i = 0; i < strlen(argv[2]); i++)
        if (!isdigit(argv[2][i]))
            goto errParam;
    int port = atoi(argv[2]);
    if (port < 1024 || port > 65535)
        goto errPort;
    return port;
errParam:
    fprintf(stderr, "Wrong parameter\nRead README.md file to get help\n");
    exit(EXIT_FAILURE);
errPort:
    fprintf(stderr, "Port number is from 1024(for safe: port<1024 is WKP) to 65535\nRead README.md file to get help\n");
    exit(EXIT_FAILURE);
}