## In workspaceFolder:

### RUN:

- make app
- ./src/server 5500
- ./src/client 127.0.0.1 5500

### Compile lib:

- cd include && make
